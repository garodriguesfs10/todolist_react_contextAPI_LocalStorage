import React, {Component} from 'react'
import Person from '../components/Person'



class AppUdemy extends Component{

    
    state={
        persons:
           [{ id:1,name:'Gabriel',age:'25'},
            {id:2,name:'Teste',age:'31'},
           { id:3,name:'Dev',age:'08'}],
        userInput:'',
        newPerson: ''
    }

    HandlerUserInput = (id,e) =>{
        //this.setState({userInput: e.target.value})
        const personIndex = this.state.persons.findIndex(p =>{return p.id === id})
        const person ={...this.state.persons[personIndex]}
        person.name = e.target.value
        const persons = [...this.state.persons]
        persons[personIndex] = person          
        this.setState({persons:persons})
      
    }

    HandlerDeletePerson = (index) =>{
        const persons = [...this.state.persons]     
        persons.splice(index,1) 
        this.setState({persons:persons})
    }

    HandlerOnchange = async (e) =>{
        await this.setState({newPerson:e.target.value})     
      
    }

   

    componentDidUpdate(){
        console.log('updated')
    }

    AddPerson = async () =>{
        if (this.state.newPerson === ''){
            return alert('Preencha o campo corretamente')
        }

        const newPearsonNow = {id:this.state.persons.length+1,name:this.state.newPerson,age:Math.floor(Math.random()*100)}
        const persons = [...this.state.persons,newPearsonNow];      
        await this.setState({persons:persons})        
        this.setState({newPerson:''})
    }

    render(){        
        return(
          
            <div>
                {this.state.persons.map((el,index)=>{
                    return <Person name={el.name} age={el.age} key={el.id} change={(e) => this.HandlerUserInput(el.id,e)} click={() => this.HandlerDeletePerson(index)}/>
                })}
                <br/>
                <br/>
                <br/>
                <input type='text' onChange={this.HandlerOnchange} value={this.state.newPerson || ''}></input>
                <button className='btn btn-sucess' onClick={this.AddPerson} style={{backgroundColor:'green',color:'white'}}>Adicionar</button>
            </div>
        )
    }
}

export default AppUdemy