import React, { Component } from 'react'
import axios from 'axios'
class Button extends Component {
    render() {
        return <button onClick={() => this.props.HandleClick(this.props.labelButton)}>{this.props.labelButton}</button>
    }
}

class MyLabel extends Component {
    render() {
        return <label>{this.props.label}</label>
    }
}

class Appclass extends Component {

    state = {
        labelText: '',
        data: [],
        date: new Date()
    }



    componentDidMount() {
        axios.get('https://api.github.com/repositories').then(({ data }) => {
            this.setState({ data })
            console.log('first')
        })

        this.timerID = setInterval(() => this.tick(),
            1000
        );
    }



    componentWillUnmount() {
        clearInterval(this.timerID);
    }

    HandleLabelChange = (label) => {
        this.setState({ labelText: label })
    }

    tick() {
        //  console.log('tick func')
        this.setState({
            date: new Date()
        });
    }


    render() {
        console.log('Renderizou a pagina')
        return (
            <div>
                <div>Você clicou no: <MyLabel label={this.state.labelText} /></div>
                <Button labelButton="Botão 1" HandleClick={this.HandleLabelChange} />
                <Button labelButton="Botão 2" HandleClick={this.HandleLabelChange} />
                <Button labelButton="Botão 3" HandleClick={this.HandleLabelChange} />
                <Button labelButton="Botão 4" HandleClick={this.HandleLabelChange} />
                <br />
                <div >Tempo: {this.state.date.toLocaleTimeString()}</div>
                <br />
                <ul>
                    {this.state.data.map((item, index) => {
                        return <li key={index}> Index:{index} -  {item.full_name}</li>
                    })}
                </ul>
            </div>
        )
    }
}

export default Appclass;