import React from 'react'
import TodoProvider from '../context/context'
import TodoList from '../components/TodoList'
import AddTodo from '../components/AddTodo'
import 'bootstrap/dist/css/bootstrap.css'


const TodoListApp = () =>{

    return(
        <div className="container mt-4">
        <TodoProvider>
            <TodoList/>
            <br/>
            <hr></hr>
            <br/>   
            <AddTodo/>          
        </TodoProvider>
        </div>
    )
}

export default TodoListApp