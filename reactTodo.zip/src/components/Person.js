import React,{Component} from 'react'

class Person extends Component{

    render(){
        return(
            <div>
                <h5>{this.props.name} - E tenho {this.props.age} anos - <button onClick={this.props.click}>Deletar</button></h5> 
                <input type='text' onChange={this.props.change} value={this.props.name}/>
            </div>

        )
    }
}

export default Person