import React, { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios'



function App() {

  const [num, setNum] = useState(0)
  const [texto, setTexto] = useState('Texto Inicial...')
  const [toggle, setToggle] = useState(false)
  //const [name, setName] = useState([''])
  const [data, setData] = useState([])

  function getNum() {
    let random = Math.floor(Math.random() * 100)
    setNum(random)
  }

  function HandlerName(event) {
    setTexto(event.target.value)
  }

  function HandlerToggle() {
    const currentStatus = toggle
    setToggle(!currentStatus)
  }

  function HandlerBotao() {

  }

  useEffect(() => {
    axios.get('https://api.github.com/repositories').then(({ data }) => {
      setData(data)
      console.log(data)
      console.log(typeof (data))
    })

  }, [])


  return (
    <div className="App">
      
      <button onClick={HandlerToggle}>Mostrar Cont</button>
      {toggle ?
        <div>
          <h5>Num: {num}</h5>
          <button onClick={getNum}>Alterar</button>
          <br></br>
          <input onChange={HandlerName} placeholder="Digite Aqui" />
          <h5>{texto}</h5>
        </div>
        : null
      }
      <ul>
        {data.map(elem => {
          return <li>{elem.full_name}</li>
        })}
      </ul>
    </div>
  );
}

export default App;
